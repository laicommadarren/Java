package com.darrenlai.hellohuman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaiDarrenAssignmentHelloHumanApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaiDarrenAssignmentHelloHumanApplication.class, args);
	}

}
