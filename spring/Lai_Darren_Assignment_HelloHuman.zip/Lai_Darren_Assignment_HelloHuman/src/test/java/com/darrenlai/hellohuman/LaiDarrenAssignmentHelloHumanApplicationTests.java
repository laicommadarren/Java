package com.darrenlai.hellohuman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaiDarrenAssignmentHelloHumanApplicationTests {

	@Test
	void contextLoads() {
	}

}
