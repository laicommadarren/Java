package com.darrenlai.savetravels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaiDarrenAssignmentSaveTravelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
