package com.darrenlai.savetravels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaiDarrenAssignmentSaveTravelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaiDarrenAssignmentSaveTravelsApplication.class, args);
	}

}
