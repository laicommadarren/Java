package com.darrenlai.books;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaiDarrenAssignmentBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
