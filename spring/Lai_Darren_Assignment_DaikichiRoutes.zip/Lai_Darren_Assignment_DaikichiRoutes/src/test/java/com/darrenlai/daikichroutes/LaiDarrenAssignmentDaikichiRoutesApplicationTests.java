package com.darrenlai.daikichroutes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaiDarrenAssignmentDaikichiRoutesApplicationTests {

	@Test
	void contextLoads() {
	}

}
