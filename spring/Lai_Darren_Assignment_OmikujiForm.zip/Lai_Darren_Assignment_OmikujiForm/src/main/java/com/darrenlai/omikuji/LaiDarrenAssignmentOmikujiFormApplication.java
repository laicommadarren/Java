package com.darrenlai.omikuji;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaiDarrenAssignmentOmikujiFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaiDarrenAssignmentOmikujiFormApplication.class, args);
	}

}
