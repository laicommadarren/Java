package com.darrenlai.burgers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaiDarrenAssignmentBurgersApplicationTests {

	@Test
	void contextLoads() {
	}

}
