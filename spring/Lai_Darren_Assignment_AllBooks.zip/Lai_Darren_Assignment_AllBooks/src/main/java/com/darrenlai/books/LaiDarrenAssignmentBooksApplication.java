package com.darrenlai.books;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaiDarrenAssignmentBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaiDarrenAssignmentBooksApplication.class, args);
	}

}
