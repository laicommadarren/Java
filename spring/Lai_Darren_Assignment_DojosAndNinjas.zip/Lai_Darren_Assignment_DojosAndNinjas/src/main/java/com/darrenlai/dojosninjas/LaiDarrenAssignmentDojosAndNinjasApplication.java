package com.darrenlai.dojosninjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaiDarrenAssignmentDojosAndNinjasApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaiDarrenAssignmentDojosAndNinjasApplication.class, args);
	}

}
