package com.darrenlai.counter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaiDarrenAssignmentCounterApplicationTests {

	@Test
	void contextLoads() {
	}

}
