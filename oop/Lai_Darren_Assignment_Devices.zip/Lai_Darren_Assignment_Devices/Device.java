public class Device {
    protected int battery = 100;


    public void displayBattery() {
        System.out.printf("Current battery: %d\n", this.battery);
    }


}