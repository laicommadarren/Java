public class DeviceTest {
    public static void main(String[] args) {
        Phone iphone = new Phone();
        iphone.makeCall();
        iphone.makeCall();
        iphone.makeCall();
        iphone.playGame();
        iphone.playGame();
        iphone.charge();


    }
}
