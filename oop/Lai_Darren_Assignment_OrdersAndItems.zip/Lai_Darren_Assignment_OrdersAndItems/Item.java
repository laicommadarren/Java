public class Item {
    String name;
    double price;
}
