public class TestStuff {
    public static void main(String[] args) {

        Gorilla harambe = new Gorilla();
        harambe.throwSomething();
        harambe.throwSomething();
        harambe.throwSomething();
        harambe.eatBanana();
        harambe.eatBanana();
        harambe.climb();
        harambe.displayEnergy();


        Bat dracula = new Bat();
        dracula.attackTown();
        dracula.attackTown();
        dracula.attackTown();
        dracula.eatHumans();
        dracula.eatHumans();
        dracula.fly();
        dracula.fly();
        dracula.displayEnergy();


    }
}
